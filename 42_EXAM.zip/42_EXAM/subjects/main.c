#include <libc.h>
typedef struct client {
    int id;
    char msg[999999];
} t_client;
t_client clients[1024];
char buffRead[999999], buffWrite[999999];
int max = 0, next_id = 0;
fd_set active_fds, Read_fds, Write_fds;
void exitError(char *str) {
    write(2, str, strlen(str));
    exit(1);
}
void sendMsg(int sender_fd) {
    for (int fd = 0; fd <= max; fd++)
        if (FD_ISSET(fd, &Write_fds) && fd != sender_fd) write(fd, buffWrite, strlen(buffWrite));
}
int main(int ac , char **arg) {
	if(ac != 2) exitError("Wrong number of arguments\n");
	int sockfd, connfd, len;
	struct sockaddr_in servaddr, cli; 

	// socket create and verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(2130706433); //127.0.0.1
	servaddr.sin_port = htons(8081); 
  
	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr))) != 0) { 
		printf("socket bind failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded..\n");
	if (listen(sockfd, 10) != 0) {
		exitError("Fatal error\n")
	}

}